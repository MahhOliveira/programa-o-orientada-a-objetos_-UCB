class Livro {
    constructor(nome, autor, ano_de_lancamento, editora, genero, numero_de_paginas) {
      this.nome = nome;
      this.autor = autor;
      this.ano_de_lancamento = ano_de_lancamento;
      this.editora = editora;
      this.genero = genero;
      this.numero_de_paginas = numero_de_paginas;
      this.disponivel = true;
    }
  
    emprestarLivro() {
      if (this.disponivel) {
        this.disponivel = false;
        console.log(`Livro "${this.nome}" emprestado com sucesso.`);
      } else {
        console.log(`Desculpe, o livro "${this.nome}" não está disponível no momento.`);
      }
    }
  
    devolverLivro() {
      if (!this.disponivel) {
        this.disponivel = true;
        console.log(`Livro "${this.nome}" devolvido com sucesso.`);
      } else {
        console.log(`O livro "${this.nome}" já está disponível.`);
      }
    }
  }
  
  class Livraria {
    constructor() {
      this.livros = [];
    }
  
    adicionarLivro(livro) {
      this.livros.push(livro);
      console.log(`Livro "${livro.nome}" adicionado à livraria.`);
    }
  
    emprestarLivro(nomeLivro) {
      const livro = this.encontrarLivroPorNome(nomeLivro);
      if (livro) {
        livro.emprestarLivro();
      } else {
        console.log(`O livro "${nomeLivro}" não está disponível na livraria.`);
      }
    }
  
    devolverLivro(nomeLivro) {
      const livro = this.encontrarLivroPorNome(nomeLivro);
      if (livro) {
        livro.devolverLivro();
      } else {
        console.log(`O livro "${nomeLivro}" não pertence à livraria.`);
      }
    }
  
    encontrarLivroPorNome(nomeLivro) {
      return this.livros.find(livro => livro.nome === nomeLivro);
    }
  
    listarLivrosDisponiveis() {
      const livrosDisponiveis = this.livros.filter(livro => livro.disponivel);
      console.log("Livros disponíveis na livraria:");
      livrosDisponiveis.forEach(livro => console.log(`- "${livro.nome}" por ${livro.autor}`));
    }
  }
  
  // Exemplo de uso
  const livraria = new Livraria();
  
  // Adicionando livros à livraria
  const livro1 = new Livro("Dom Casmurro", "Machado de Assis", 1899, "Editora Garnier", "Romance", 256);
  const livro2 = new Livro("1984", "George Orwell", 1949, "Editora ABC", "Ficção", 328);
  const livro3 = new Livro("Grande Sertão: Veredas", "João Guimarães Rosa", 1956, "José Olympio", "Ficção", 616);
  const livro4 = new Livro("O Cortiço", "Aluísio Azevedo", 1890, "Martin Claret", "Romance naturalista", 352);
  const livro5 = new Livro("Memórias Póstumas de Brás Cubas", "Machado de Assis", 1881, "Editora Garnier", "Romance", 240);
  livraria.adicionarLivro(livro1);
  livraria.adicionarLivro(livro2);
  livraria.adicionarLivro(livro3);
  livraria.adicionarLivro(livro4);
  livraria.adicionarLivro(livro5);
  
  // Realizando empréstimo e devolução de livros
  livraria.emprestarLivro("Dom Casmurro");
  livraria.emprestarLivro("1984");
  livraria.devolverLivro("1984");
  
  // Listando livros disponíveis
  livraria.listarLivrosDisponiveis();

  
  // 